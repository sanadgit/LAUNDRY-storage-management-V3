/**
 * واجهة فرز الملابس - Clothes Sorting Interface
 * Design: Clean Professional Blue
 * - خلفية فاتحة مع أزرق ملكي وبرتقالي للتمييز
 * - لوحة مفاتيح صناعية على اليسار
 * - تفاصيل الطلب على اليمين
 * - خطوط Cairo + Nunito + JetBrains Mono
 */

import { useState, useCallback, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";
import { t } from "@/lib/translations";
import LanguageToggle from "@/components/LanguageToggle";
import FinalPackagingLabel from "@/components/FinalPackagingLabel";
import PrintableFinalLabel from "@/components/PrintableFinalLabel";
import {
  Search,
  Printer,
  Package,
  User,
  Hash,
  Layers,
  CheckCircle2,
  Clock,
  ChevronLeft,
  Shirt,
  Tag,
  BarChart3,
  X,
  Delete,
  Box,
  Zap,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────
interface OrderItem {
  id: string;
  name: string;
  quantity: number;
  size: string;
  color: string;
}

interface Order {
  orderId: string;
  clientId: string;
  status: "processing" | "done" | "pending";
  items: OrderItem[];
  totalPieces: number;
  totalQuantity: number;
  date: string;
}

// ─── Mock Data ────────────────────────────────────────────────────────────────
const MOCK_ORDERS: Record<string, Order> = {
  "A1234": {
    orderId: "A1234",
    clientId: "C-5521",
    status: "processing",
    date: "2026-05-16",
    items: [
      { id: "1", name: "قميص رجالي", quantity: 12, size: "XL", color: "أبيض" },
      { id: "2", name: "بنطلون جينز", quantity: 8, size: "32", color: "أزرق" },
      { id: "3", name: "تيشيرت", quantity: 20, size: "L", color: "أسود" },
    ],
    totalPieces: 3,
    totalQuantity: 40,
  },
  "M5678": {
    orderId: "M5678",
    clientId: "C-8834",
    status: "done",
    date: "2026-05-15",
    items: [
      { id: "1", name: "فستان نسائي", quantity: 15, size: "M", color: "أحمر" },
      { id: "2", name: "بلوزة", quantity: 10, size: "S", color: "بيج" },
    ],
    totalPieces: 2,
    totalQuantity: 25,
  },
  "R9012": {
    orderId: "R9012",
    clientId: "C-3317",
    status: "pending",
    date: "2026-05-16",
    items: [
      { id: "1", name: "جاكيت شتوي", quantity: 5, size: "XXL", color: "رمادي" },
      { id: "2", name: "كنزة صوف", quantity: 18, size: "L", color: "أخضر" },
      { id: "3", name: "شورت رياضي", quantity: 30, size: "M", color: "أسود" },
      { id: "4", name: "قميص كاجوال", quantity: 12, size: "XL", color: "أزرق" },
    ],
    totalPieces: 4,
    totalQuantity: 65,
  },
  "W3456": {
    orderId: "W3456",
    clientId: "C-9901",
    status: "processing",
    date: "2026-05-16",
    items: [
      { id: "1", name: "عباءة", quantity: 7, size: "فري", color: "أسود" },
      { id: "2", name: "حجاب", quantity: 25, size: "فري", color: "متعدد" },
    ],
    totalPieces: 2,
    totalQuantity: 32,
  },
  "Z7890": {
    orderId: "Z7890",
    clientId: "C-6643",
    status: "done",
    date: "2026-05-14",
    items: [
      { id: "1", name: "بدلة رسمية", quantity: 3, size: "52", color: "كحلي" },
      { id: "2", name: "قميص رسمي", quantity: 6, size: "42", color: "أبيض" },
      { id: "3", name: "ربطة عنق", quantity: 6, size: "فري", color: "متعدد" },
    ],
    totalPieces: 3,
    totalQuantity: 15,
  },
};

// ─── Keyboard Layout ──────────────────────────────────────────────────────────
const KEYBOARD_ROWS = [
  ["Z", "A", "M", "R", "W"],
  ["1", "2", "3", "4", "5"],
  ["6", "7", "8", "9", "0"],
];

// ─── Sub-components ───────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: Order["status"] }) {
  const config = {
    processing: { label: "جاري الفرز", icon: Clock, cls: "status-processing" },
    done: { label: "مكتمل", icon: CheckCircle2, cls: "status-done" },
    pending: {
      label: "في الانتظار",
      icon: Clock,
      cls: "bg-amber-50 text-amber-700 border border-amber-200",
    },
  }[status];
  const Icon = config.icon;
  return (
    <span className={`status-badge ${config.cls}`}>
      <Icon size={12} />
      {config.label}
    </span>
  );
}

function EmptyOrderPanel() {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-4 text-center px-8">
      <div className="w-20 h-20 rounded-2xl bg-blue-50 flex items-center justify-center">
        <Package size={36} className="text-blue-300" />
      </div>
      <div>
        <p className="text-lg font-bold text-slate-400" style={{ fontFamily: "Cairo, sans-serif" }}>
          لا يوجد طلب محدد
        </p>
        <p className="text-sm text-slate-300 mt-1" style={{ fontFamily: "Cairo, sans-serif" }}>
          ابحث برقم الطلب لعرض التفاصيل
        </p>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
export default function Home() {
  const { language } = useLanguage();
  const [, setLocation] = useLocation();
  const [searchValue, setSearchValue] = useState("");
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [pressedKey, setPressedKey] = useState<string | null>(null);
  const [isPrinting, setIsPrinting] = useState(false);
  const [showFinalLabel, setShowFinalLabel] = useState(false);
  const [printingFinalLabel, setPrintingFinalLabel] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);
  const printLabelRef = useRef<HTMLDivElement>(null);

  // Check if all items are completed
  const allItemsCompleted = currentOrder
    ? currentOrder.items.every((item) => item.quantity === 0)
    : false;

  const handleKeyPress = useCallback((key: string) => {
    setPressedKey(key);
    setTimeout(() => setPressedKey(null), 150);
    setSearchValue((prev) => prev + key);
    setNotFound(false);
  }, []);

  const handleDelete = useCallback(() => {
    setPressedKey("DEL");
    setTimeout(() => setPressedKey(null), 150);
    setSearchValue((prev) => prev.slice(0, -1));
    setNotFound(false);
  }, []);

  const handleClear = useCallback(() => {
    setSearchValue("");
    setCurrentOrder(null);
    setNotFound(false);
  }, []);

  const handleSearch = useCallback(() => {
    const val = searchValue.trim().toUpperCase();
    if (!val) return;
    const order = MOCK_ORDERS[val];
    if (order) {
      setCurrentOrder(order);
      setNotFound(false);
    } else {
      setCurrentOrder(null);
      setNotFound(true);
    }
  }, [searchValue]);

  const handlePrint = useCallback(() => {
    setIsPrinting(true);
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
    }, 300);
  }, []);

  const handlePrintFinalLabel = useCallback(() => {
    setPrintingFinalLabel(true);
    setTimeout(() => {
      window.print();
      setPrintingFinalLabel(false);
      setShowFinalLabel(false);
      // Reset after printing
      handleClear();
    }, 500);
  }, [handleClear]);

  // Show final label when all items are completed
  useEffect(() => {
    if (allItemsCompleted && currentOrder) {
      setShowFinalLabel(true);
    }
  }, [allItemsCompleted, currentOrder]);

  const statusColors: Record<Order["status"], string> = {
    processing: "text-blue-600",
    done: "text-green-600",
    pending: "text-amber-600",
  };

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background: "linear-gradient(145deg, oklch(0.96 0.008 240) 0%, oklch(0.98 0.004 255) 100%)",
        fontFamily: "Cairo, sans-serif",
        direction: "rtl",
      }}
    >
      {/* ── Header ── */}
      <header
        className="flex items-center justify-between px-6 py-3 shadow-sm"
        style={{
          background: "linear-gradient(135deg, oklch(0.22 0.06 255) 0%, oklch(0.28 0.08 255) 100%)",
          borderBottom: "1px solid oklch(0.35 0.06 255)",
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: "oklch(0.55 0.18 255 / 0.3)" }}
          >
            <Shirt size={22} className="text-blue-300" />
          </div>
          <div>
            <h1
              className="text-white font-extrabold text-lg leading-tight"
              style={{ fontFamily: "Cairo, sans-serif" }}
            >
              {t("clothesSortingSystem", language)}
            </h1>
            <p className="text-blue-300 text-xs font-medium">{t("clothesSortingSystemEng", language)}</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-blue-200 text-sm">
            <BarChart3 size={16} />
            <span style={{ fontFamily: "Nunito, sans-serif" }}>
              {Object.keys(MOCK_ORDERS).length} {t("activeOrders", language)}
            </span>
          </div>
          <button
            onClick={() => setLocation("/ironing")}
            className="px-4 py-1.5 rounded-lg text-xs font-bold transition-all"
            style={{
              background: "oklch(0.3 0.1 255)",
              color: "oklch(0.85 0.01 255)",
              border: "1px solid oklch(0.4 0.1 255)",
              fontFamily: "Cairo, sans-serif",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.35 0.12 255)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.3 0.1 255)";
            }}
          >
            <span className="flex items-center gap-2">
              <Zap size={14} />
              {t("ironing", language)}
            </span>
          </button>
          <button
            onClick={() => setLocation("/blankets")}
            className="px-4 py-1.5 rounded-lg text-xs font-bold transition-all"
            style={{
              background: "oklch(0.3 0.1 255)",
              color: "oklch(0.85 0.01 255)",
              border: "1px solid oklch(0.4 0.1 255)",
              fontFamily: "Cairo, sans-serif",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.35 0.12 255)";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.3 0.1 255)";
            }}
          >
            <span className="flex items-center gap-2">
              <Box size={14} />
              {t("blankets", language)}
            </span>
          </button>
          <LanguageToggle />
          <div
            className="px-3 py-1.5 rounded-lg text-xs font-bold"
            style={{
              background: "oklch(0.62 0.18 145 / 0.2)",
              color: "oklch(0.75 0.18 145)",
              border: "1px solid oklch(0.62 0.18 145 / 0.3)",
              fontFamily: "Nunito, sans-serif",
            }}
          >
            ● {t("online", language)}
          </div>
        </div>
      </header>

      {/* ── Main Layout ── */}
      <main className="flex-1 flex gap-4 p-4" style={{ minHeight: 0 }}>

        {/* ══════════════════════════════════════════
            LEFT PANEL — Search + Keyboard
        ══════════════════════════════════════════ */}
        <motion.div
          className="flex flex-col gap-4 animate-slide-in-left"
          style={{ width: "44%", minWidth: 340 }}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1] }}
        >
          {/* Search Box */}
          <div
            className="rounded-2xl p-5 shadow-lg"
            style={{
              background: "white",
              border: "1px solid oklch(0.88 0.01 240)",
              boxShadow: "0 4px 24px oklch(0.22 0.06 255 / 0.08)",
            }}
          >
            <div className="flex items-center gap-2 mb-3">
              <Search size={18} style={{ color: "oklch(0.42 0.18 255)" }} />
              <span
                className="font-bold text-slate-600 text-sm"
                style={{ fontFamily: "Cairo, sans-serif" }}
              >
                البحث برقم الطلب
              </span>
            </div>

            {/* Search Input Display */}
            <div
              className="relative rounded-xl overflow-hidden mb-3"
              style={{
                background: "oklch(0.96 0.008 240)",
                border: `2px solid ${searchValue ? "oklch(0.42 0.18 255)" : "oklch(0.88 0.01 240)"}`,
                transition: "border-color 0.2s ease",
                boxShadow: searchValue ? "0 0 0 4px oklch(0.55 0.18 255 / 0.1)" : "none",
              }}
            >
              <div className="flex items-center px-4 py-3 gap-3">
                <Hash size={18} style={{ color: "oklch(0.55 0.18 255)" }} />
                <span
                  className="flex-1 text-2xl font-black tracking-widest"
                  style={{
                    fontFamily: "JetBrains Mono, monospace",
                    color: searchValue ? "oklch(0.22 0.06 255)" : "oklch(0.75 0.02 255)",
                    minHeight: "2rem",
                    letterSpacing: "0.2em",
                  }}
                >
                  {searchValue || "_ _ _ _ _"}
                </span>
                {searchValue && (
                  <button
                    onClick={handleClear}
                    className="w-7 h-7 rounded-full flex items-center justify-center transition-all"
                    style={{
                      background: "oklch(0.88 0.01 240)",
                      color: "oklch(0.52 0.02 255)",
                    }}
                  >
                    <X size={14} />
                  </button>
                )}
              </div>
            </div>

            {/* Search Button */}
            <button
              onClick={handleSearch}
              className="w-full py-3 rounded-xl font-bold text-white text-base transition-all"
              style={{
                background: "linear-gradient(135deg, oklch(0.42 0.18 255), oklch(0.5 0.2 255))",
                boxShadow: "0 4px 15px oklch(0.42 0.18 255 / 0.35)",
                fontFamily: "Cairo, sans-serif",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-1px)";
                (e.currentTarget as HTMLButtonElement).style.boxShadow =
                  "0 6px 20px oklch(0.42 0.18 255 / 0.45)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.transform = "translateY(0)";
                (e.currentTarget as HTMLButtonElement).style.boxShadow =
                  "0 4px 15px oklch(0.42 0.18 255 / 0.35)";
              }}
            >
              <span className="flex items-center justify-center gap-2">
                <Search size={18} />
                بحث
              </span>
            </button>

            {/* Not Found Message */}
            <AnimatePresence>
              {notFound && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="mt-3 px-4 py-2.5 rounded-xl text-sm font-semibold text-center"
                  style={{
                    background: "oklch(0.6 0.22 25 / 0.08)",
                    color: "oklch(0.5 0.22 25)",
                    border: "1px solid oklch(0.6 0.22 25 / 0.2)",
                    fontFamily: "Cairo, sans-serif",
                  }}
                >
                  لم يتم العثور على الطلب "{searchValue}"
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Keyboard Panel */}
          <div
            className="flex-1 rounded-2xl p-5 shadow-lg"
            style={{
              background: "linear-gradient(145deg, oklch(0.2 0.05 255) 0%, oklch(0.25 0.07 255) 100%)",
              border: "1px solid oklch(0.3 0.06 255)",
              boxShadow: "0 8px 32px oklch(0.15 0.05 255 / 0.4)",
            }}
          >
            {/* Keyboard Header - Branded */}
            <div className="mb-5 pb-4 border-b" style={{ borderColor: "oklch(0.3 0.06 255)" }}>
              <div className="flex items-center justify-between">
                <div>
                  <h3
                    className="text-white font-black text-sm mb-1"
                    style={{ fontFamily: "Cairo, sans-serif" }}
                  >
                    Clothes Sorting System
                  </h3>
                  <p
                    className="text-blue-300 text-xs"
                    style={{ fontFamily: "Cairo, sans-serif" }}
                  >
                    نظام فرز الملابس
                  </p>
                </div>
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-400 opacity-60" />
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-400 opacity-60" />
                  <div className="w-2.5 h-2.5 rounded-full bg-green-400 opacity-60" />
                </div>
              </div>
            </div>

            {/* Keys */}
            <div className="flex flex-col gap-3">
              {KEYBOARD_ROWS.map((row, rowIdx) => (
                <div key={rowIdx} className="flex gap-3 justify-center">
                  {row.map((key) => (
                    <motion.button
                      key={key}
                      className="key-btn flex-1 h-16 flex items-center justify-center"
                      style={{
                        fontFamily: rowIdx === 0 ? "Nunito, sans-serif" : "JetBrains Mono, monospace",
                        fontSize: "1.5rem",
                        background: pressedKey === key
                          ? "oklch(0.42 0.18 255)"
                          : undefined,
                      }}
                      onClick={() => handleKeyPress(key)}
                      whileTap={{ scale: 0.93, y: 3 }}
                    >
                      {key}
                    </motion.button>
                  ))}
                </div>
              ))}

              {/* Bottom row: Clear + Delete + Enter */}
              <div className="flex gap-3 mt-1">
                <motion.button
                  className="key-btn key-btn-delete flex-1 h-14 flex items-center justify-center gap-2 text-base"
                  onClick={handleDelete}
                  whileTap={{ scale: 0.93, y: 3 }}
                  style={{ fontFamily: "Cairo, sans-serif", fontSize: "0.9rem" }}
                >
                  <Delete size={18} />
                  حذف
                </motion.button>

                <motion.button
                  className="key-btn key-btn-special flex-1 h-14 flex items-center justify-center gap-2 text-base"
                  onClick={handleClear}
                  whileTap={{ scale: 0.93, y: 3 }}
                  style={{ fontFamily: "Cairo, sans-serif", fontSize: "0.9rem" }}
                >
                  <X size={18} />
                  مسح
                </motion.button>

                <motion.button
                  className="key-btn key-btn-enter flex-1 h-14 flex items-center justify-center gap-2 text-base"
                  onClick={handleSearch}
                  whileTap={{ scale: 0.93, y: 3 }}
                  style={{ fontFamily: "Cairo, sans-serif", fontSize: "0.9rem" }}
                >
                  <ChevronLeft size={18} />
                  بحث
                </motion.button>
              </div>
            </div>

            {/* Quick Access Hint */}
            <div
              className="mt-4 pt-3 flex items-center justify-center gap-2"
              style={{ borderTop: "1px solid oklch(0.3 0.06 255 / 0.5)" }}
            >
              <span className="text-blue-400 text-xs" style={{ fontFamily: "Cairo, sans-serif" }}>
                أمثلة: A1234 · M5678 · R9012 · W3456 · Z7890
              </span>
            </div>
          </div>
        </motion.div>

        {/* ══════════════════════════════════════════
            RIGHT PANEL — Order Details
        ══════════════════════════════════════════ */}
        <motion.div
          className="flex-1 rounded-2xl shadow-lg overflow-hidden"
          style={{
            background: "white",
            border: "1px solid oklch(0.88 0.01 240)",
            boxShadow: "0 4px 24px oklch(0.22 0.06 255 / 0.08)",
          }}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.35, ease: [0.23, 1, 0.32, 1], delay: 0.05 }}
        >
          <AnimatePresence mode="wait">
            {currentOrder ? (
              <motion.div
                key={currentOrder.orderId}
                className="flex flex-col h-full"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
              >
                {/* Order Header */}
                <div
                  className="px-6 py-5"
                  style={{
                    background: "linear-gradient(135deg, oklch(0.22 0.06 255) 0%, oklch(0.3 0.1 255) 100%)",
                  }}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Package size={18} className="text-blue-300" />
                        <span
                          className="text-blue-200 text-sm font-medium"
                          style={{ fontFamily: "Cairo, sans-serif" }}
                        >
                          تفاصيل الطلب
                        </span>
                      </div>
                      <h2
                        className="text-white font-black text-3xl tracking-wider"
                        style={{ fontFamily: "JetBrains Mono, monospace" }}
                      >
                        #{currentOrder.orderId}
                      </h2>
                    </div>
                    <StatusBadge status={currentOrder.status} />
                  </div>
                </div>

                {/* Order Meta */}
                <div
                  className="grid grid-cols-2 gap-0"
                  style={{ borderBottom: "1px solid oklch(0.92 0.005 240)" }}
                >
                  <div
                    className="px-6 py-4 flex items-center gap-3"
                    style={{ borderLeft: "1px solid oklch(0.92 0.005 240)" }}
                  >
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ background: "oklch(0.42 0.18 255 / 0.1)" }}
                    >
                      <Hash size={18} style={{ color: "oklch(0.42 0.18 255)" }} />
                    </div>
                    <div>
                      <p
                        className="text-xs font-semibold text-slate-400 mb-0.5"
                        style={{ fontFamily: "Cairo, sans-serif" }}
                      >
                        رقم الطلب
                      </p>
                      <p
                        className="font-black text-lg text-slate-800"
                        style={{ fontFamily: "JetBrains Mono, monospace" }}
                      >
                        {currentOrder.orderId}
                      </p>
                    </div>
                  </div>

                  <div className="px-6 py-4 flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ background: "oklch(0.7 0.18 45 / 0.1)" }}
                    >
                      <User size={18} style={{ color: "oklch(0.6 0.18 45)" }} />
                    </div>
                    <div>
                      <p
                        className="text-xs font-semibold text-slate-400 mb-0.5"
                        style={{ fontFamily: "Cairo, sans-serif" }}
                      >
                        رقم العميل
                      </p>
                      <p
                        className="font-black text-lg text-slate-800"
                        style={{ fontFamily: "JetBrains Mono, monospace" }}
                      >
                        {currentOrder.clientId}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Summary Stats */}
                <div
                  className="grid grid-cols-3 gap-0"
                  style={{ borderBottom: "1px solid oklch(0.92 0.005 240)" }}
                >
                  {[
                    {
                      label: "القطع",
                      value: currentOrder.totalPieces,
                      icon: Layers,
                      color: "oklch(0.42 0.18 255)",
                      bg: "oklch(0.42 0.18 255 / 0.08)",
                    },
                    {
                      label: "العدد",
                      value: currentOrder.items.length,
                      icon: Tag,
                      color: "oklch(0.6 0.18 45)",
                      bg: "oklch(0.6 0.18 45 / 0.08)",
                    },
                    {
                      label: "الكمية",
                      value: currentOrder.totalQuantity,
                      icon: BarChart3,
                      color: "oklch(0.55 0.18 145)",
                      bg: "oklch(0.55 0.18 145 / 0.08)",
                    },
                  ].map((stat, i) => (
                    <div
                      key={i}
                      className="px-4 py-4 flex flex-col items-center gap-1.5"
                      style={{
                        borderLeft: i < 2 ? "1px solid oklch(0.92 0.005 240)" : "none",
                      }}
                    >
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center"
                        style={{ background: stat.bg }}
                      >
                        <stat.icon size={17} style={{ color: stat.color }} />
                      </div>
                      <span
                        className="text-2xl font-black"
                        style={{ color: stat.color, fontFamily: "JetBrains Mono, monospace" }}
                      >
                        {stat.value}
                      </span>
                      <span
                        className="text-xs font-semibold text-slate-400"
                        style={{ fontFamily: "Cairo, sans-serif" }}
                      >
                        {stat.label}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Items Table */}
                <div className="flex-1 overflow-auto px-6 py-4" ref={printRef}>
                  <div className="flex items-center gap-2 mb-3">
                    <Shirt size={16} style={{ color: "oklch(0.42 0.18 255)" }} />
                    <span
                      className="text-sm font-bold text-slate-600"
                      style={{ fontFamily: "Cairo, sans-serif" }}
                    >
                      تفاصيل القطع
                    </span>
                  </div>

                  <div className="rounded-xl overflow-hidden" style={{ border: "1px solid oklch(0.9 0.008 240)" }}>
                    {/* Table Header */}
                    <div
                      className="grid grid-cols-4 px-4 py-2.5"
                      style={{
                        background: "oklch(0.95 0.01 255)",
                        borderBottom: "1px solid oklch(0.9 0.008 240)",
                      }}
                    >
                      {["نوع القطعة", "الكمية", "المقاس", "اللون"].map((h) => (
                        <span
                          key={h}
                          className="text-xs font-bold text-slate-500 text-center"
                          style={{ fontFamily: "Cairo, sans-serif" }}
                        >
                          {h}
                        </span>
                      ))}
                    </div>

                    {/* Table Rows */}
                    {currentOrder.items.map((item, idx) => (
                      <motion.div
                        key={item.id}
                        className="grid grid-cols-4 px-4 py-3 items-center"
                        style={{
                          background: idx % 2 === 0 ? "white" : "oklch(0.98 0.003 240)",
                          borderBottom:
                            idx < currentOrder.items.length - 1
                              ? "1px solid oklch(0.93 0.005 240)"
                              : "none",
                        }}
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.06, duration: 0.2 }}
                      >
                        <span
                          className="text-sm font-bold text-slate-700 text-center"
                          style={{ fontFamily: "Cairo, sans-serif" }}
                        >
                          {item.name}
                        </span>
                        <span
                          className="text-center font-black text-lg"
                          style={{
                            color: "oklch(0.42 0.18 255)",
                            fontFamily: "JetBrains Mono, monospace",
                          }}
                        >
                          {item.quantity}
                        </span>
                        <span
                          className="text-center text-sm font-semibold"
                          style={{
                            color: "oklch(0.55 0.02 255)",
                            fontFamily: "Nunito, sans-serif",
                          }}
                        >
                          {item.size}
                        </span>
                        <div className="flex justify-center">
                          <span
                            className="px-2.5 py-1 rounded-full text-xs font-bold"
                            style={{
                              background: "oklch(0.6 0.18 45 / 0.1)",
                              color: "oklch(0.5 0.18 45)",
                              border: "1px solid oklch(0.6 0.18 45 / 0.2)",
                              fontFamily: "Cairo, sans-serif",
                            }}
                          >
                            {item.color}
                          </span>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Print Button */}
                <div
                  className="px-6 py-4"
                  style={{ borderTop: "1px solid oklch(0.92 0.005 240)" }}
                >
                  <motion.button
                    className="print-btn w-full py-4 flex items-center justify-center gap-3 text-lg font-black"
                    onClick={handlePrint}
                    disabled={isPrinting}
                    whileTap={{ scale: 0.97 }}
                    style={{ fontFamily: "Cairo, sans-serif" }}
                  >
                    <Printer size={22} />
                    {isPrinting ? "جاري الطباعة..." : "طباعة الطلب"}
                  </motion.button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="empty"
                className="h-full"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <EmptyOrderPanel />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </main>

      {/* ── Footer ── */}
      <footer
        className="px-6 py-2.5 flex items-center justify-between text-xs"
        style={{
          background: "oklch(0.96 0.008 240)",
          borderTop: "1px solid oklch(0.88 0.01 240)",
          color: "oklch(0.6 0.02 255)",
          fontFamily: "Cairo, sans-serif",
        }}
      >
        <span>نظام فرز الملابس — الإصدار 1.0</span>
        <span style={{ fontFamily: "Nunito, sans-serif" }}>
          {new Date().toLocaleDateString("ar-SA", {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
          })}
        </span>
      </footer>

      {/* Final Label Modal */}
      <AnimatePresence>
        {showFinalLabel && currentOrder && (
          <FinalPackagingLabel
            orderId={currentOrder.orderId}
            totalItems={currentOrder.totalPieces}
            totalQuantity={currentOrder.totalQuantity}
            date={currentOrder.date}
            onPrint={handlePrintFinalLabel}
            onClose={() => setShowFinalLabel(false)}
          />
        )}
      </AnimatePresence>

      {/* Hidden Print Container */}
      {printingFinalLabel && currentOrder && (
        <div ref={printLabelRef} style={{ display: "none" }}>
          <PrintableFinalLabel
            orderId={currentOrder.orderId}
            totalItems={currentOrder.totalPieces}
            totalQuantity={currentOrder.totalQuantity}
            date={currentOrder.date}
          />
        </div>
      )}

      {/* Print Styles */}
      <style>{`
        @media print {
          body * { visibility: hidden; }
          .print-area, .print-area * { visibility: visible; }
          header, footer, .key-btn, button { display: none !important; }
        }
      `}</style>
    </div>
  );
}
